import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import NavBar from '../components/NavBar';
import ChatItem from '../components/ChatItem';
import { colors, spacing, fontSize, fontWeights, borderRadius } from '../styles/theme';
import { useChatStore } from '../stores/chatStore';

const ChatList = ({ navigation }) => {
  const { chats, setSelectedChat } = useChatStore();

  const handleChatPress = (chatId) => {
    setSelectedChat(chatId);
    navigation.navigate('ChatDetail');
  };

  return (
    <View style={styles.container}>
      <NavBar title="讨论" />
      <ScrollView style={styles.chatList}>
        {chats.map((chat) => (
          <ChatItem key={chat.id} chat={chat} onPress={() => handleChatPress(chat.id)} />
        ))}
      </ScrollView>
      <TouchableOpacity style={styles.fab} onPress={() => {}}>
        <Text style={styles.fabText}>+</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  chatList: {
    flex: 1,
  },
  fab: {
    position: 'absolute',
    right: spacing.lg,
    bottom: 100,
    width: 56,
    height: 56,
    backgroundColor: colors.primary,
    borderRadius: borderRadius.full,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  fabText: {
    fontSize: 32,
    fontWeight: fontWeights.medium,
    color: '#FFFFFF',
    lineHeight: 1,
  },
});

export default ChatList;