import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Platform, StatusBar } from 'react-native';
import { colors, fontSize, fontWeights, spacing } from '../styles/theme';

const NavBar = ({ title, showBack = false, onBack, rightAction, rightText }) => {
  const statusBarHeight = Platform.OS === 'ios' ? 44 : StatusBar.currentHeight || 20;

  return (
    <View style={[styles.container, { paddingTop: statusBarHeight }]}>
      <View style={styles.content}>
        {showBack && (
          <TouchableOpacity style={styles.backButton} onPress={onBack}>
            <Text style={styles.backIcon}>←</Text>
          </TouchableOpacity>
        )}
        <Text style={styles.title}>{title}</Text>
        {rightAction && (
          <TouchableOpacity style={styles.rightButton} onPress={rightAction}>
            <Text style={styles.rightText}>{rightText}</Text>
          </TouchableOpacity>
        )}
        {!showBack && !rightAction && <View style={styles.placeholder} />}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.primary,
    height: Platform.OS === 'ios' ? 88 : 64,
    justifyContent: 'flex-end',
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    height: 44,
    paddingHorizontal: spacing.lg,
  },
  title: {
    fontSize: fontSize.xxl,
    fontWeight: fontWeights.bold,
    color: '#FFFFFF',
  },
  backButton: {
    position: 'absolute',
    left: spacing.lg,
    width: 44,
    height: 44,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backIcon: {
    fontSize: 28,
    color: '#FFFFFF',
    fontWeight: fontWeights.medium,
  },
  rightButton: {
    position: 'absolute',
    right: spacing.lg,
    paddingHorizontal: spacing.md,
    height: 44,
    justifyContent: 'center',
    alignItems: 'center',
  },
  rightText: {
    fontSize: fontSize.lg,
    color: '#FFFFFF',
    fontWeight: fontWeights.medium,
  },
  placeholder: {
    position: 'absolute',
    right: spacing.lg,
    width: 44,
  },
});

export default NavBar;