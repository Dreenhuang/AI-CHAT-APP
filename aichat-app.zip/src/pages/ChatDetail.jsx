import React, { useState, useRef, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, TouchableOpacity, KeyboardAvoidingView, Platform } from 'react-native';
import NavBar from '../components/NavBar';
import MessageBubble from '../components/MessageBubble';
import { colors, spacing, fontSize, fontWeights, borderRadius } from '../styles/theme';
import { useChatStore } from '../stores/chatStore';

const ChatDetail = ({ navigation }) => {
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollViewRef = useRef(null);
  const { messages, getCurrentChat, addMessage } = useChatStore();

  const currentChat = getCurrentChat();

  useEffect(() => {
    scrollViewRef.current?.scrollToEnd({ animated: true });
  }, [messages]);

  useEffect(() => {
    if (Math.random() > 0.5) {
      setIsTyping(true);
      const timer = setTimeout(() => {
        setIsTyping(false);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [messages]);

  const handleSend = () => {
    if (!inputText.trim()) return;
    
    addMessage({
      sender: '你',
      avatar: '#7CB342',
      content: inputText,
      time: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }),
      isAI: false,
    });
    
    setInputText('');
    
    setTimeout(() => {
      setIsTyping(true);
      setTimeout(() => {
        setIsTyping(false);
        addMessage({
          sender: currentChat?.name || 'AI',
          avatar: currentChat?.avatar || '#AFDD22',
          content: '收到你的消息，我来分析一下...这是一个很好的观点，让我深入思考一下这个问题。核心要点确实值得探讨，我认为可以从几个方面来分析这个议题。',
          time: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }),
          isAI: true,
        });
      }, 2000);
    }, 500);
  };

  return (
    <View style={styles.container}>
      <NavBar 
        title={currentChat?.name || '讨论'} 
        showBack 
        onBack={() => navigation.goBack()}
        rightText="⋮"
      />
      
      <ScrollView ref={scrollViewRef} style={styles.messageList}>
        {messages.map((message) => (
          <MessageBubble key={message.id} message={message} />
        ))}
        {isTyping && (
          <View style={styles.typingIndicator}>
            <View style={styles.typingAvatar}>
              <Text style={styles.typingAvatarText}>{currentChat?.name?.charAt(0) || 'A'}</Text>
            </View>
            <View style={styles.typingBubble}>
              <View style={styles.typingDots}>
                <View style={styles.dot} />
                <View style={styles.dot} />
                <View style={styles.dot} />
              </View>
            </View>
          </View>
        )}
      </ScrollView>

      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.inputContainer}
      >
        <View style={styles.inputBar}>
          <TouchableOpacity style={styles.iconButton}>
            <Text style={styles.iconText}>🤖</Text>
          </TouchableOpacity>
          <TextInput
            style={styles.input}
            placeholder="输入讨论内容..."
            value={inputText}
            onChangeText={setInputText}
            onSubmitEditing={handleSend}
            multiline
            maxLength={500}
          />
          <TouchableOpacity style={styles.sendButton} onPress={handleSend} disabled={!inputText.trim()}>
            <Text style={styles.sendText}>发送</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  messageList: {
    flex: 1,
    paddingTop: spacing.lg,
  },
  typingIndicator: {
    flexDirection: 'row',
    marginBottom: spacing.lg,
    paddingHorizontal: spacing.lg,
  },
  typingAvatar: {
    width: 40,
    height: 40,
    borderRadius: borderRadius.md,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.sm,
  },
  typingAvatarText: {
    fontSize: fontSize.md,
    fontWeight: fontWeights.semiBold,
    color: '#FFFFFF',
  },
  typingBubble: {
    backgroundColor: colors.bubbleAI,
    borderRadius: borderRadius.lg,
    borderTopLeftRadius: borderRadius.sm,
    padding: spacing.md,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.08,
    shadowRadius: 2,
  },
  typingDots: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  dot: {
    width: 6,
    height: 6,
    backgroundColor: colors.textSecondary,
    borderRadius: borderRadius.full,
    animation: {
      type: 'pulse',
      duration: 1.5,
      iterations: -1,
    },
  },
  inputContainer: {
    backgroundColor: colors.surface,
    borderTopWidth: 1,
    borderTopColor: colors.divider,
  },
  inputBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    gap: spacing.sm,
  },
  iconButton: {
    width: 36,
    height: 36,
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconText: {
    fontSize: 20,
  },
  input: {
    flex: 1,
    backgroundColor: colors.background,
    borderRadius: borderRadius.lg,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    fontSize: fontSize.lg,
    maxHeight: 120,
  },
  sendButton: {
    backgroundColor: colors.primary,
    borderRadius: borderRadius.xl,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    minWidth: 60,
    alignItems: 'center',
  },
  sendText: {
    fontSize: fontSize.md,
    fontWeight: fontWeights.semiBold,
    color: '#FFFFFF',
  },
});

export default ChatDetail;