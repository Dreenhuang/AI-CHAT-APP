import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import NavBar from '../components/NavBar';
import { colors, spacing, fontSize, fontWeights, borderRadius } from '../styles/theme';
import { useChatStore } from '../stores/chatStore';

const Profile = ({ navigation }) => {
  const { currentUser, isLoggedIn } = useChatStore();

  const menuItems = [
    { title: '设置', icon: '⚙️' },
    { title: '帮助与反馈', icon: '❓' },
    { title: '关于我们', icon: 'ℹ️' },
  ];

  return (
    <View style={styles.container}>
      <NavBar title="我" />
      
      <ScrollView style={styles.content}>
        <View style={styles.header}>
          <View style={[styles.avatar, { backgroundColor: currentUser.avatar }]}>
            <Text style={styles.avatarText}>辩</Text>
          </View>
          <View style={styles.userInfo}>
            <Text style={styles.userName}>{currentUser.name}</Text>
            <Text style={styles.userPhone}>{currentUser.phone}</Text>
            <View style={styles.memberBadge}>
              <Text style={styles.memberText}>{currentUser.memberLevel}</Text>
            </View>
          </View>
          {!isLoggedIn && (
            <TouchableOpacity style={styles.loginButton}>
              <Text style={styles.loginText}>登录</Text>
            </TouchableOpacity>
          )}
        </View>

        <View style={styles.statsCard}>
          <View style={styles.statItem}>
            <Text style={styles.statNum}>{currentUser.debateCount}</Text>
            <Text style={styles.statLabel}>辩论记录</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statNum}>{currentUser.groupCount}</Text>
            <Text style={styles.statLabel}>我的群组</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statNum}>{currentUser.friendCount}</Text>
            <Text style={styles.statLabel}>我的好友</Text>
          </View>
        </View>

        <View style={styles.menuCard}>
          {menuItems.map((item, index) => (
            <TouchableOpacity key={index} style={styles.menuItem}>
              <Text style={styles.menuIcon}>{item.icon}</Text>
              <Text style={styles.menuText}>{item.title}</Text>
              <Text style={styles.menuArrow}>›</Text>
            </TouchableOpacity>
          ))}
        </View>

        {isLoggedIn && (
          <TouchableOpacity style={styles.logoutButton}>
            <Text style={styles.logoutText}>退出登录</Text>
          </TouchableOpacity>
        )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    flex: 1,
  },
  header: {
    backgroundColor: colors.surface,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.xl,
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    width: 72,
    height: 72,
    borderRadius: borderRadius.md,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.lg,
  },
  avatarText: {
    fontSize: 32,
    fontWeight: fontWeights.bold,
    color: '#FFFFFF',
  },
  userInfo: {
    flex: 1,
  },
  userName: {
    fontSize: fontSize.xxxl,
    fontWeight: fontWeights.semiBold,
    color: colors.textPrimary,
    marginBottom: spacing.xs,
  },
  userPhone: {
    fontSize: fontSize.md,
    color: colors.textSecondary,
    marginBottom: spacing.sm,
  },
  memberBadge: {
    backgroundColor: colors.primaryLight,
    width: 60,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.sm,
  },
  memberText: {
    fontSize: fontSize.sm,
    color: colors.primaryDark,
    fontWeight: fontWeights.medium,
  },
  loginButton: {
    backgroundColor: colors.primary,
    borderRadius: borderRadius.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },
  loginText: {
    fontSize: fontSize.md,
    fontWeight: fontWeights.semiBold,
    color: '#FFFFFF',
  },
  statsCard: {
    backgroundColor: colors.surface,
    marginHorizontal: spacing.lg,
    marginVertical: spacing.md,
    borderRadius: borderRadius.lg,
    paddingVertical: spacing.lg,
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  statItem: {
    alignItems: 'center',
  },
  statNum: {
    fontSize: fontSize.xxxl,
    fontWeight: fontWeights.bold,
    color: colors.primary,
    marginBottom: spacing.xs,
  },
  statLabel: {
    fontSize: fontSize.sm,
    color: colors.textSecondary,
  },
  statDivider: {
    width: 1,
    backgroundColor: colors.divider,
  },
  menuCard: {
    backgroundColor: colors.surface,
    marginHorizontal: spacing.lg,
    borderRadius: borderRadius.lg,
    marginBottom: spacing.md,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.divider,
  },
  menuItem:last-child: {
    borderBottomWidth: 0,
  },
  menuIcon: {
    fontSize: 20,
    marginRight: spacing.md,
  },
  menuText: {
    flex: 1,
    fontSize: fontSize.xl,
    color: colors.textPrimary,
  },
  menuArrow: {
    fontSize: fontSize.xxl,
    color: colors.textSecondary,
  },
  logoutButton: {
    backgroundColor: colors.surface,
    marginHorizontal: spacing.lg,
    borderRadius: borderRadius.lg,
    paddingVertical: spacing.md,
    alignItems: 'center',
  },
  logoutText: {
    fontSize: fontSize.xl,
    color: colors.error,
  },
});

export default Profile;