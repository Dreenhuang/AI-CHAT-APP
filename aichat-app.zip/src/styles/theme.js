export const colors = {
  primary: '#AFDD22',
  primaryLight: '#C5E1A5',
  primaryDark: '#8BC34A',
  bubbleUser: '#95EC69',
  bubbleAI: '#FFFFFF',
  background: '#F5F5F5',
  surface: '#FFFFFF',
  textPrimary: '#1F1F1F',
  textSecondary: '#888888',
  textPlaceholder: '#BBBBBB',
  divider: '#E5E5E5',
  error: '#FA5151',
  success: '#52C41A',
  warning: '#FAAD14',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
};

export const fontSize = {
  xs: 12,
  sm: 13,
  md: 14,
  lg: 15,
  xl: 16,
  xxl: 17,
  xxxl: 18,
};

export const fontWeights = {
  regular: '400',
  medium: '500',
  semiBold: '600',
  bold: '700',
};

export const borderRadius = {
  sm: 4,
  md: 8,
  lg: 12,
  xl: 16,
  full: 9999,
};

export const shadows = {
  sm: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
  },
  md: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 2,
  },
  lg: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 4,
  },
};

export const theme = {
  colors,
  spacing,
  fontSize,
  fontWeights,
  borderRadius,
  shadows,
};

export default theme;