import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput } from 'react-native';
import NavBar from '../components/NavBar';
import { colors, spacing, fontSize, fontWeights, borderRadius } from '../styles/theme';
import { useChatStore } from '../stores/chatStore';

const Contacts = ({ navigation }) => {
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const { chats } = useChatStore();

  const groups = chats.filter(c => c.type === 'group');
  const souls = chats.filter(c => c.type === 'soul');

  const handleChatPress = (chatId) => {
    useChatStore.getState().setSelectedChat(chatId);
    navigation.navigate('ChatDetail');
  };

  return (
    <View style={styles.container}>
      <NavBar title="通讯录" />
      
      {showSearch ? (
        <View style={styles.searchBar}>
          <TextInput
            style={styles.searchInput}
            placeholder="搜索"
            value={searchQuery}
            onChangeText={setSearchQuery}
            autoFocus
          />
        </View>
      ) : (
        <TouchableOpacity style={styles.searchPlaceholder} onPress={() => setShowSearch(true)}>
          <Text style={styles.searchText}>点击搜索</Text>
        </TouchableOpacity>
      )}

      <ScrollView style={styles.list}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>群聊</Text>
          {groups.map((chat) => (
            <TouchableOpacity key={chat.id} style={styles.contactItem} onPress={() => handleChatPress(chat.id)}>
              <View style={[styles.avatar, { backgroundColor: chat.avatar }]}>
                <Text style={styles.avatarText}>{chat.name.charAt(0)}</Text>
              </View>
              <View style={styles.contactContent}>
                <Text style={styles.contactName}>{chat.name}</Text>
                <Text style={styles.contactDesc}>{chat.participants?.length || 0}人参与</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>好友</Text>
          {souls.map((chat) => (
            <TouchableOpacity key={chat.id} style={styles.contactItem} onPress={() => handleChatPress(chat.id)}>
              <View style={[styles.avatar, { backgroundColor: chat.avatar }]}>
                <Text style={styles.avatarText}>{chat.name.charAt(0)}</Text>
              </View>
              <View style={styles.contactContent}>
                <Text style={styles.contactName}>{chat.name}</Text>
                <Text style={styles.contactDesc}>{chat.personality}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  searchBar: {
    backgroundColor: colors.surface,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.divider,
  },
  searchInput: {
    backgroundColor: colors.background,
    borderRadius: borderRadius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    fontSize: fontSize.lg,
    color: colors.textPrimary,
  },
  searchPlaceholder: {
    backgroundColor: colors.surface,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.divider,
  },
  searchText: {
    fontSize: fontSize.lg,
    color: colors.textPlaceholder,
  },
  list: {
    flex: 1,
  },
  section: {
    backgroundColor: colors.surface,
    marginBottom: spacing.sm,
  },
  sectionTitle: {
    fontSize: fontSize.sm,
    color: colors.textSecondary,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    fontWeight: fontWeights.medium,
  },
  contactItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.divider,
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: borderRadius.md,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },
  avatarText: {
    fontSize: fontSize.md,
    fontWeight: fontWeights.semiBold,
    color: '#FFFFFF',
  },
  contactContent: {
    flex: 1,
  },
  contactName: {
    fontSize: fontSize.xl,
    color: colors.textPrimary,
    fontWeight: fontWeights.medium,
    marginBottom: spacing.xs,
  },
  contactDesc: {
    fontSize: fontSize.sm,
    color: colors.textSecondary,
  },
});

export default Contacts;