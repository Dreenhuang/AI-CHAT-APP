import { create } from 'zustand';

const mockChats = [
  {
    id: '1',
    name: '标准正反方辩论',
    avatar: '#AFDD22',
    lastMessage: '主持人正在分析议题...',
    time: '10:30',
    unread: 2,
    type: 'group',
    participants: ['主持人', '正方代表', '反方代表'],
  },
  {
    id: '2',
    name: '头脑风暴讨论',
    avatar: '#95EC69',
    lastMessage: '5人参与讨论中',
    time: '9:15',
    unread: 0,
    type: 'group',
    participants: ['创新先锋', '技术达人', '谨慎分析'],
  },
  {
    id: '3',
    name: '中立协调型主持人',
    avatar: '#AED581',
    lastMessage: '你好，今天讨论什么？',
    time: '8:00',
    unread: 0,
    type: 'soul',
    personality: '温和公正',
  },
  {
    id: '4',
    name: '创新先锋提案者',
    avatar: '#BA68C8',
    lastMessage: '我有一个新想法！',
    time: '昨天',
    unread: 0,
    type: 'soul',
    personality: '敢于突破',
  },
];

const mockTopics = [
  {
    id: '1',
    title: 'AI是否会取代人类工作？',
    description: '探讨AI技术对就业市场的影响和未来趋势',
    category: '科技',
    participants: 128,
  },
  {
    id: '2',
    title: '年轻人应该先买房还是租房？',
    description: '讨论年轻人的居住选择和理财规划',
    category: '生活',
    participants: 256,
  },
  {
    id: '3',
    title: '远程办公是否应该成为常态？',
    description: '分析远程办公的优缺点和未来趋势',
    category: '职场',
    participants: 189,
  },
  {
    id: '4',
    title: '短视频对青少年的影响',
    description: '探讨短视频平台对青少年成长的影响',
    category: '社会',
    participants: 312,
  },
  {
    id: '5',
    title: '电动汽车是否比燃油车更环保？',
    description: '从全生命周期角度分析电动汽车的环保性',
    category: '环保',
    participants: 145,
  },
];

const mockMessages = [
  {
    id: '1',
    sender: '主持人',
    avatar: '#AFDD22',
    content: '各位好，今天我们来讨论"AI是否会取代人类工作"这个议题。首先，请正方代表阐述观点。',
    time: '10:30',
    isAI: true,
  },
  {
    id: '2',
    sender: '正方代表',
    avatar: '#64B5F6',
    content: '我认为AI确实会取代大量重复性工作。根据研究，未来10年内，约40%的工作岗位将受到AI自动化的影响。这是技术进步的必然趋势，就像工业革命一样，会带来更高效的生产力。',
    time: '10:32',
    isAI: true,
  },
  {
    id: '3',
    sender: '反方代表',
    avatar: '#EF5350',
    content: '我不同意。AI虽然能自动化很多任务，但人类的创造力、情感智慧和复杂决策能力是AI无法替代的。历史证明，技术进步总会创造新的工作岗位，而不是简单地取代。',
    time: '10:35',
    isAI: true,
  },
  {
    id: '4',
    sender: '你',
    avatar: '#7CB342',
    content: '我觉得两者说的都有道理。关键是如何平衡AI带来的效率提升和人类的价值。我们应该思考如何让AI成为人类的工具，而不是竞争对手。',
    time: '10:38',
    isAI: false,
  },
  {
    id: '5',
    sender: '主持人',
    avatar: '#AFDD22',
    content: '非常好的观点！确实，AI不是要取代人类，而是要增强人类的能力。让我们继续深入讨论...',
    time: '10:40',
    isAI: true,
  },
];

const categories = ['全部', '科技', '生活', '职场', '社会', '环保', '教育', '经济'];

export const useChatStore = create((set) => ({
  chats: mockChats,
  topics: mockTopics,
  messages: mockMessages,
  categories,
  selectedChat: null,
  selectedCategory: '全部',
  isLoggedIn: false,
  currentUser: {
    name: '游客用户',
    phone: '138****1234',
    avatar: '#AFDD22',
    memberLevel: '正式会员',
    debateCount: 5,
    groupCount: 3,
    friendCount: 8,
  },

  setSelectedChat: (chatId) => set({ selectedChat: chatId }),
  setSelectedCategory: (category) => set({ selectedCategory: category }),
  login: (phone, password) => set({ isLoggedIn: true }),
  logout: () => set({ isLoggedIn: false }),
  
  filterTopicsByCategory: () => {
    const store = useChatStore.getState();
    if (store.selectedCategory === '全部') {
      return store.topics;
    }
    return store.topics.filter(topic => topic.category === store.selectedCategory);
  },

  getCurrentChat: () => {
    const store = useChatStore.getState();
    if (!store.selectedChat) return null;
    return store.chats.find(chat => chat.id === store.selectedChat);
  },

  addMessage: (message) => set((state) => ({
    messages: [...state.messages, {
      ...message,
      id: Date.now().toString(),
    }],
  })),

  addChat: (chat) => set((state) => ({
    chats: [...state.chats, {
      ...chat,
      id: Date.now().toString(),
    }],
  })),
}));

export default useChatStore;