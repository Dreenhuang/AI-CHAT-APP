import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView } from 'react-native';
import { colors, spacing, fontSize, fontWeights, borderRadius } from '../styles/theme';
import { useChatStore } from '../stores/chatStore';

const Login = ({ navigation }) => {
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useChatStore();

  const handleLogin = () => {
    if (!phone || !password) {
      alert('请输入手机号和密码');
      return;
    }
    
    setIsLoading(true);
    setTimeout(() => {
      login(phone, password);
      setIsLoading(false);
      navigation.navigate('Main');
    }, 1000);
  };

  const handleGuest = () => {
    navigation.navigate('Main');
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.logoSection}>
        <View style={styles.logo}>
          <Text style={styles.logoText}>辩</Text>
        </View>
        <Text style={styles.appName}>PRD辩论</Text>
      </View>

      <View style={styles.formSection}>
        <View style={styles.formGroup}>
          <Text style={styles.label}>手机号</Text>
          <TextInput
            style={styles.input}
            placeholder="请输入手机号"
            value={phone}
            onChangeText={setPhone}
            keyboardType="phone-pad"
            maxLength={11}
          />
        </View>

        <View style={styles.formGroup}>
          <Text style={styles.label}>密码</Text>
          <TextInput
            style={styles.input}
            placeholder="请输入密码"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />
        </View>

        <TouchableOpacity style={styles.loginButton} onPress={handleLogin} disabled={isLoading}>
          <Text style={styles.loginText}>
            {isLoading ? '登录中...' : '登录'}
          </Text>
        </TouchableOpacity>

        <View style={styles.divider}>
          <View style={styles.dividerLine} />
          <Text style={styles.dividerText}>或</Text>
          <View style={styles.dividerLine} />
        </View>

        <TouchableOpacity style={styles.guestButton} onPress={handleGuest}>
          <Text style={styles.guestText}>先看看（游客模式）</Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.agreement}>
        登录即表示同意《用户协议》和《隐私政策》
      </Text>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.xl,
  },
  logoSection: {
    alignItems: 'center',
    marginTop: spacing.xxl * 2,
    marginBottom: spacing.xxl * 2,
  },
  logo: {
    width: 100,
    height: 100,
    backgroundColor: colors.primary,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: spacing.lg,
  },
  logoText: {
    fontSize: 48,
    fontWeight: fontWeights.bold,
    color: '#FFFFFF',
  },
  appName: {
    fontSize: fontSize.xxxl * 1.2,
    fontWeight: fontWeights.bold,
    color: colors.primary,
  },
  formSection: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.xl,
  },
  formGroup: {
    marginBottom: spacing.lg,
  },
  label: {
    fontSize: fontSize.md,
    color: colors.textPrimary,
    marginBottom: spacing.sm,
    fontWeight: fontWeights.medium,
  },
  input: {
    backgroundColor: colors.background,
    borderRadius: borderRadius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    fontSize: fontSize.lg,
    color: colors.textPrimary,
  },
  loginButton: {
    backgroundColor: colors.primary,
    borderRadius: borderRadius.md,
    paddingVertical: spacing.md,
    alignItems: 'center',
    marginTop: spacing.lg,
    marginBottom: spacing.md,
  },
  loginText: {
    fontSize: fontSize.xl,
    fontWeight: fontWeights.semiBold,
    color: '#FFFFFF',
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: spacing.lg,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: colors.divider,
  },
  dividerText: {
    paddingHorizontal: spacing.lg,
    fontSize: fontSize.sm,
    color: colors.textSecondary,
  },
  guestButton: {
    alignItems: 'center',
  },
  guestText: {
    fontSize: fontSize.lg,
    color: colors.textSecondary,
  },
  agreement: {
    fontSize: fontSize.xs,
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: spacing.xxl,
  },
});

export default Login;