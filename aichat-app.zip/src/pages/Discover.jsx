import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Picker } from 'react-native';
import NavBar from '../components/NavBar';
import TopicCard from '../components/TopicCard';
import { colors, spacing, fontSize, fontWeights, borderRadius } from '../styles/theme';
import { useChatStore } from '../stores/chatStore';

const Discover = ({ navigation }) => {
  const [selectedCategory, setSelectedCategory] = useState('全部');
  const { categories, topics, setSelectedCategory: storeSetCategory } = useChatStore();

  const filteredTopics = selectedCategory === '全部' 
    ? topics 
    : topics.filter(t => t.category === selectedCategory);

  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
    storeSetCategory(category);
  };

  const handleTopicPress = (topic) => {
    navigation.navigate('ChatDetail');
  };

  return (
    <View style={styles.container}>
      <NavBar title="发现" />
      
      <View style={styles.filterBar}>
        <TouchableOpacity style={styles.filterButton} onPress={() => {}}>
          <Text style={styles.filterText}>{selectedCategory}</Text>
          <Text style={styles.filterArrow}>▼</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.topicList}>
        {filteredTopics.length > 0 ? (
          filteredTopics.map((topic) => (
            <TopicCard key={topic.id} topic={topic} onPress={() => handleTopicPress(topic)} />
          ))
        ) : (
          <View style={styles.emptyState}>
            <Text style={styles.emptyText}>暂无该分类下的议题</Text>
            <TouchableOpacity style={styles.emptyButton} onPress={() => handleCategoryChange('全部')}>
              <Text style={styles.emptyButtonText}>查看全部议题</Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  filterBar: {
    backgroundColor: colors.surface,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.divider,
  },
  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.background,
    borderRadius: borderRadius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    width: 140,
  },
  filterText: {
    fontSize: fontSize.lg,
    color: colors.textPrimary,
    flex: 1,
  },
  filterArrow: {
    fontSize: fontSize.sm,
    color: colors.textSecondary,
  },
  topicList: {
    flex: 1,
    paddingTop: spacing.sm,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.xl,
  },
  emptyText: {
    fontSize: fontSize.lg,
    color: colors.textSecondary,
    marginBottom: spacing.lg,
  },
  emptyButton: {
    backgroundColor: colors.primary,
    borderRadius: borderRadius.xl,
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
  },
  emptyButtonText: {
    fontSize: fontSize.md,
    fontWeight: fontWeights.semiBold,
    color: '#FFFFFF',
  },
});

export default Discover;