import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, fontSize, fontWeights, spacing, borderRadius } from '../styles/theme';

const MessageBubble = ({ message }) => {
  const isUser = !message.isAI;

  return (
    <View style={[styles.container, isUser ? styles.userContainer : styles.aiContainer]}>
      <View style={styles.avatarContainer}>
        <View style={[styles.avatar, { backgroundColor: message.avatar }]}>
          <Text style={styles.avatarText}>
            {message.sender.charAt(0)}
          </Text>
        </View>
      </View>
      <View style={[styles.contentContainer, isUser ? styles.userContent : styles.aiContent]}>
        <Text style={styles.sender}>{message.sender}</Text>
        <View style={[styles.bubble, isUser ? styles.userBubble : styles.aiBubble]}>
          <Text style={styles.messageText}>{message.content}</Text>
        </View>
        <Text style={styles.time}>{message.time}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    marginBottom: spacing.lg,
    paddingHorizontal: spacing.lg,
  },
  aiContainer: {
    flexDirection: 'row',
  },
  userContainer: {
    flexDirection: 'row-reverse',
  },
  avatarContainer: {
    width: 40,
    height: 40,
    flexShrink: 0,
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: borderRadius.md,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    fontSize: fontSize.md,
    fontWeight: fontWeights.semiBold,
    color: '#FFFFFF',
  },
  contentContainer: {
    maxWidth: '75%',
  },
  aiContent: {
    marginLeft: spacing.sm,
  },
  userContent: {
    marginRight: spacing.sm,
    alignItems: 'flex-end',
  },
  sender: {
    fontSize: fontSize.sm,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
    paddingHorizontal: spacing.sm,
  },
  bubble: {
    padding: spacing.md,
    borderRadius: borderRadius.lg,
    minWidth: 80,
  },
  aiBubble: {
    backgroundColor: colors.bubbleAI,
    borderTopLeftRadius: borderRadius.sm,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.08,
    shadowRadius: 2,
  },
  userBubble: {
    backgroundColor: colors.bubbleUser,
    borderTopRightRadius: borderRadius.sm,
  },
  messageText: {
    fontSize: fontSize.lg,
    color: colors.textPrimary,
    lineHeight: 1.5,
  },
  time: {
    fontSize: fontSize.xs,
    color: colors.textSecondary,
    marginTop: spacing.xs,
    paddingHorizontal: spacing.sm,
  },
});

export default MessageBubble;