import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { View, Text, StyleSheet } from 'react-native';
import { colors, fontSize, fontWeights, spacing } from './styles/theme';
import Login from './pages/Login';
import ChatList from './pages/ChatList';
import Contacts from './pages/Contacts';
import ChatDetail from './pages/ChatDetail';
import Discover from './pages/Discover';
import Profile from './pages/Profile';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const TabIcon = ({ label, focused }) => (
  <View style={styles.tabIcon}>
    <Text style={[styles.tabText, focused ? styles.tabTextActive : styles.tabTextInactive]}>
      {label}
    </Text>
  </View>
);

const MainTabs = () => (
  <Tab.Navigator
    screenOptions={{
      tabBarStyle: {
        backgroundColor: '#FFFFFF',
        borderTopWidth: 1,
        borderTopColor: colors.divider,
        height: 50,
        paddingBottom: spacing.sm,
        paddingTop: spacing.xs,
      },
      tabBarShowLabel: false,
      headerShown: false,
    }}
  >
    <Tab.Screen
      name="ChatList"
      component={ChatList}
      options={{
        tabBarIcon: ({ focused }) => <TabIcon label="讨论" focused={focused} />,
      }}
    />
    <Tab.Screen
      name="Contacts"
      component={Contacts}
      options={{
        tabBarIcon: ({ focused }) => <TabIcon label="通讯录" focused={focused} />,
      }}
    />
    <Tab.Screen
      name="Discover"
      component={Discover}
      options={{
        tabBarIcon: ({ focused }) => <TabIcon label="发现" focused={focused} />,
      }}
    />
    <Tab.Screen
      name="Profile"
      component={Profile}
      options={{
        tabBarIcon: ({ focused }) => <TabIcon label="我" focused={focused} />,
      }}
    />
  </Tab.Navigator>
);

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerShown: false,
        }}
      >
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="Main" component={MainTabs} />
        <Stack.Screen name="ChatDetail" component={ChatDetail} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  tabIcon: {
    alignItems: 'center',
    justifyContent: 'center',
    height: 44,
  },
  tabText: {
    fontSize: fontSize.sm,
    fontWeight: fontWeights.medium,
  },
  tabTextActive: {
    color: colors.primary,
  },
  tabTextInactive: {
    color: colors.textSecondary,
  },
});

export default App;